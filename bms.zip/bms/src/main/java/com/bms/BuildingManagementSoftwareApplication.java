package com.bms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuildingManagementSoftwareApplication {

	public static void main(String[] args) {
		SpringApplication.run(BuildingManagementSoftwareApplication.class, args);
	}

}
